#!/bin/bash
scp -rp -i ~/mykey.pem ~/maas/mahout ubuntu@$1:~
scp -i ~/mykey.pem ~/maas/01proxy ubuntu@$1:~
scp -i ~/mykey.pem ~/maas/install_mahout_node.sh ubuntu@$1:~
ssh -i ~/mykey.pem ubuntu@192.168.50.178 'sudo bash install_mahout_node.sh'
