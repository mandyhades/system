<?php
	if(!isset($_SESSION))
	{
		session_start();
	}
?>
<?php
class Maas_model extends CI_Model{
	private $keystoneDB;
    private $ip_controller;
    protected $_gallery_path = "";
    protected $_gallery_url = "";
    public function __construct(){
        parent::__construct();
        global $keystoneDB;
        global $ip_controller;
		include(APPPATH . '/config/' . 'global.php');
		$ip_controller = $GLOBAL['ip_controller'];
        $this->_gallery_url = base_url()."public/images/";
        $this->_gallery_path = realpath(APPPATH. "../public/images");
    }

    public function validate(){   	
    	global $ip_controller;
		$ADD_ENDPOINT_TOKEN = 'http://'.$ip_controller.':5000/v2.0/';
        $username = $this->security->xss_clean($this->input->post('username'));     
        $password = $this->security->xss_clean($this->input->post('password'));
        $_SESSION['uname'] = $username;

        $f_login = shell_exec("./shell/login.sh Alo1 Alo2 Alo3");
        if ($f_login==1){
                return 1;
        }else{
        	return 2;
        }
    }

    public function list_cluster(){
	$cluster_data = shell_exec("./shell/list_cluster.sh");
		if(!$fw = fopen ("shell/cluster.txt","r")){
		    echo ("File not found");
		}else{
		    $i=0;
		    while(!feof ($fw)){
		    	$j="cluster".$i;
           		$cluster[$j]=fgets ($fw);
               	$i++;
       		}
		    fclose ($fw);
		return $cluster;
		}
    }

    public function do_action(){
        if(substr($_POST['taskOption'], 0, 7)=="Install"){
            $tmp =  substr($_POST['taskOption'], 8);
            $ip_master = shell_exec("./shell/checkip.sh $tmp");
            if(!$fw = fopen ("shell/info.txt","r")){
            echo ("File not found");
            }else{
                $i=0;
                while(!feof ($fw)){
                    $cluster[$i]=fgetc ($fw);
                    $i++;
                }
                fclose ($fw);
                $ip = "";
                $size = sizeof($cluster);
                for ($i=$size-24; $i<$size-10; $i++){
                    $ip = $ip.$cluster[$i]; 
                }
                echo $ip;
                $install_act = shell_exec("./shell/install_mahout.sh $ip");
            }
        }
        else if (substr($_POST['taskOption'], 0, 7)=="Uploadl") {
            echo "Upload";
        }
    }
}
?>
