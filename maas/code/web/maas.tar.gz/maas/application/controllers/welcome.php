<?php
	if(!isset($_SESSION)) {
		session_start();
	}
?>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function  __construct() {
        parent::__construct();
        $this->load->helper("url");
        $this->load->helper(array('form', 'url'));
    }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('login');
	}

	public function do_login(){
		$this->load->Model("maas_model");
		$data = $this->maas_model->validate();
		if($data==0 || $data==2){
			redirect('');
        }else{
			$cdata = $this->maas_model->list_cluster();
	        	$this->load->view('cluster', $cdata);
        }
	}

	public function do_exit(){
		unset($_SESSION['uname']);
		unset($_SESSION['pass']);
		$this->load->view('login');
	}

	public function detail_cluster(){
		echo $_SESSION['clusterid'];
		unset($_SESSION['clusterid']);
	}

	public function do_upload(){
		if($this->input->post("ok")){
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '204800';
            $this->load->library("upload", $config);
            if($this->upload->do_upload("img")){
                $check = $this->upload->data();
                echo $check['file_name'];
            }else{
                $data['errors'] = $this->upload->display_errors();
                $this->load->view("cluster", $data);
            }
        }
	}

	public function action(){
		$this->load->Model("maas_model");
		$data = $this->maas_model->do_action();
	}
}
