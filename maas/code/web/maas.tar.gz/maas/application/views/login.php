<?php
	if(!isset($_SESSION)) {
		session_start();
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>MaaS</title>
	<link href="<?php echo base_url()?>css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
	<div id="wap">
		<div id="loRe">
			<img src="<?php echo base_url()?>images/logo_hpcc.png" alt="BCloud logo" />
			<?php
				echo validation_errors();
   				echo form_open('welcome/do_login');
   				$input_username = array(
					  'name'        => 'username',
					  'id'          => 'username',
					  'value'       => '',
					  'maxlength'   => '100',
				);
				$input_password = array(
					  'name'        => 'password',
					  'id'          => 'password',
					  'value'       => '',
					  'maxlength'   => '100',
				);
				$input_autologin = array(
					'name'			=> 'autologin',
					'id'			=> 'autologin',
				);
			?>
   			<div id="login">
				<h3><font color="#00b5f0">ĐĂNG NHẬP</font></h3>
				<ul>
					<li>
						<label for="username"><b>Tài khoản</b></label>
						<input name="username" type="text" />
					</li>

					<li>
						<label for="password"><b>Mật khẩu</b></label>
						<input name="password" type="password" />
					</li>

					<li><input type="submit" id="login_button" value=""/></li>
				</ul>
			</div>
			</form><!-- End #login -->
			<div class="clearfix"></div>
		</div><!-- End loRe -->
	</div><!-- End #wap -->
</body>
</html>