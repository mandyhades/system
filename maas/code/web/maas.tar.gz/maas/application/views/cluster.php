<?php
	if(!isset($_SESSION)) {
		session_start();
	}

	$upload=array(
	    "name" => "img",
	    "size" => "25",
	);
	
	$i=0;
	while (true) {
		$tmp="cluster".$i;
		if ($$tmp!="") {
			$cluster_index[$i]=$$tmp;
			$i++;
		}
		else{
			break;
		}
	}
?>

<script type="text/javascript"> 
	function showHide(divId){
	    var theDiv = document.getElementById(divId);
	    if(theDiv.style.display=="none"){
	        theDiv.style.display="";
	    }else{
	        theDiv.style.display="none";
	    }    
	}
</script>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>MaaS</title>
	<link href="<?php echo base_url()?>css/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
	<div id="wapper">
		<div id="header">
			<b><a>
				Xin chào 
				<?php
					if(isset($_SESSION['uname'])){
						echo $_SESSION['uname'] ;
					}
					else{}
				?>
			</a></b>
			<b><a href="<?php echo base_url()?>index.php/welcome/do_exit"> (Thoát)</a></b>
		</div>
		<div class="clearfix"></div>
		<div id="cluster">
		    <div id="list-vms">
			    <div class="des-row">
			        <div class="col-style"><b>Cluster</b></div>
			        <div class="col-style-small"><b>Mahout</b></div>
			        <div class="col-style-small"><b>Jobs</div>
			        <div class="col-style-small"><b>Action</b></div>
			    </div><!--End #des-row-->

				<?php $j=0; foreach ($cluster_index as $p): ?>
		            <?php if ($j%2==0): ?>	   
			            <div class="row">
			                <div class="col-style"><b><?php echo $p; ?></b></div>
			                <div class="col-style-small">No</div>
			                <div class="col-style-small"><input type="button" onclick="showHide('hidethis')" value="Show"></div>
			                <div class="col-style">
			                	<?php
									echo validation_errors();
					   				echo form_open('welcome/action');
								?>
					   				<select name="taskOption">
									      <option value="">Choose</option>
									      <option value="Install-<?php echo $p; ?>">Install</option>
									      <option value="Uploadl-<?php echo $p; ?>">Upload</option>
									</select>
									<input type="submit" value="Submit">
								</form><!-- End #action -->
			                </div>
			            </div> <!--End #row-->
			            <script type="text/javascript">
			                
			            </script>

			            <?php else: ?>
			            <div class="row" style="background:#f4f4f4;">
			                <div class="col-style"><b><?php echo $p; ?></b></div>
			                <div class="col-style-small">No</div>
			                <div class="col-style-small"><input type="button" onclick="showHide('hidethis')" value="Show"></div>
			                <div class="col-style">
			                	<?php
									echo validation_errors();
					   				echo form_open('welcome/action');
								?>
					   				<select name="taskOption">
									      <option value="">Choose</option>
									      <option value="Install-<?php echo $p; ?>">Install</option>
									      <option value="Uploadl-<?php echo $p; ?>">Upload</option>
									</select>
									<input type="submit" value="Submit">
								</form><!-- End #action -->
			                </div>
			            </div><!--End #row-->
		            <?php endif; ?>
		            <?php $j++; ?>
		        <?php endforeach;?>
		    </div><!-- End #list-vms --><br />
		</div><!-- End #cluster --><br />

		<div id="cluster">
		    <div id="list-vms">
			    <div class="des-row">
			        <div class="col-style"><b>Jobs</b></div>
			    </div><!--End #des-row-->

				<div id="hidethis" style="display:none;" class="col-style-name">
					<h2>List jobs...!</h2>
				</div>
		    </div><!-- End #list-vms --><br />
		</div><!-- End #cluster --><br />
	</div><!-- End #wapper -->
</body>
</html>